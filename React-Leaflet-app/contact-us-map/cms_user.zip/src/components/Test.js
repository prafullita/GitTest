import React from "react";
import 'bootstrap/dist/css/bootstrap.min.css'; 

const Test=()=>{
 
    return(
        <div className="container">
            <div className="row">
                <div className="col-md-4"> 
                <div className="card">
                <div className="card-body">
                <h4 className="card-title">Bologna</h4>
                <h6 className="card-subtitle mb-2">Emilia-Romagna Region, Italy</h6>
                <p className="card-text">It is the seventh most populous city in Italy, at the heart of a metropolitan area of about one million people. </p>
                <a href="#" className="card-link text-primary">Book a Trip</a>
                </div>
                </div>
                </div>

                <div className="col-md-4"> 
                <div className="card">
                <div className="card-body">
                <h4 className="card-title">Bologna</h4>
                <h6 className="card-subtitle mb-2">Emilia-Romagna Region, Italy</h6>
                <p className="card-text">It is the seventh most populous city in Italy, at the heart of a metropolitan area of about one million people. </p>
                <a href="#" className="card-link text-primary">Book a Trip</a>
                </div>
                </div>
                </div>

                <div className="col-md-4"> 
                <div className="card">
                <div className="card-body">
                <h4 className="card-title">Bologna</h4>
                <h6 className="card-subtitle mb-2">Emilia-Romagna Region, Italy</h6>
                <p className="card-text">It is the seventh most populous city in Italy, at the heart of a metropolitan area of about one million people. </p>
                <a href="#" className="card-link text-primary">Book a Trip</a>
                </div>
                </div>
                </div>

        </div>
           </div>
    )
        
}

export default Test;