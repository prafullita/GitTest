import React from "react";


const Youtube=()=>{
    return(
<div className="container-sm" style={{marginTop:5}}>
<div class="row">
  <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4">
    <iframe src="https://www.youtube.com/embed/DlkChWb-C5g" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
  </div>
  <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4">
    <iframe src="https://www.youtube.com/embed/meiX1lzQ7DU" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
  </div>
  <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4">
    <iframe src="https://www.youtube.com/embed/9FHyhZILhZw" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
  </div>
  
    </div> 


<div class="row">
  <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4">
    <iframe  src="https://www.youtube.com/embed/moVRcxy0_pQ" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
  </div>
  <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4">
    <iframe src="https://www.youtube.com/embed/qSyN3dEdCPg" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
  </div>
  <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4">
    <iframe src="https://www.youtube.com/embed/whCvSe1yBA0" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
  </div>
</div>

  <div class="row">
    <div class="col-xs-1 col-sm-1 col-md-4 col-lg-4">
      <iframe  src="https://www.youtube.com/embed/GBXB90B_toc" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
    </div>
  
    <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4">
      <iframe src="https://www.youtube.com/embed/2CUqPJoaf0M" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
    </div>
  </div>
</div>
    )
}

export default Youtube;