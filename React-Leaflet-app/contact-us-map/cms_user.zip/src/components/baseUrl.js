const baseUrl = "http://localhost:8082/";
export default baseUrl;