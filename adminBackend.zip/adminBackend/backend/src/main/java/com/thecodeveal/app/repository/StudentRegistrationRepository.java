//package com.thecodeveal.app.repository;
//
//import org.springframework.data.jpa.repository.JpaRepository;
//import org.springframework.stereotype.Repository;
//
//import com.thecodeveal.app.entities.StudentRegistration;
//
//
//@Repository
//public interface StudentRegistrationRepository extends JpaRepository<StudentRegistration,Integer> {
//
//	StudentRegistration getById(int regId);
//	
//}
//
